<?php
/*
    Auteur: Sven Wikberg
    Date: 19/06/2017
    Description: D'affichage des donnees
*/

define('DB_HOST', 'localhost');
define('DB_NAME', 'overwatchcollection');
define('DB_USER', 'oc_admin');
define('DB_PWD', 'overwatch123');
?>